package com.settleking.service.authservice.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.endpoint.AuthorizationEndpoint;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;

@Configuration
@EnableAuthorizationServer
public class AuthorizationServerConfig extends AuthorizationServerConfigurerAdapter {

    private String privateKey = "MIIEwAIBADANBgkqhkiG9w0BAQEFAASCBKowggSmAgEAAoIBAQC90YNTR3pHSXdzgoj80m+Z9eAWGYdgxjJxPotvVBK759JRzFwE7BeN6oTpcV254ChnaU10DlT/8fYe0IDTf13QlEJvtv6V4Jrw99wH3/tguBAc/lMe0bn2lo10XaKCS2ADv0yzOVmmbe/nG1PxWjWY//XwWc3ONvgij84I1cH/raTYu1NXGlXBSCCbwMskkdZC/5TUbJCnDDgOOxa9rP6dNsW9wYsn7ydMEQs/UlNqi4dSpCWj2vXoUrlcaq1ev9+82xFli+orXA9AdEovtFFAVMFrGF8K4dg9A6DXAKIm0wPkKVpfznTbvdpUXoZMqdGi4O7m/fWmvu2XIKYLscqBAgMBAAECggEBAI+UvHaxGZB0xPNN6Rr8fsiB0OhGlT2hjiRVABnNCYKzX0bagzyB7Ws+2xzN0Oy53zYh1CGWebtEpjw20UuqCyesDfj8/eQXCnx9sCUQytAlSqLzyaIFWFprFULRVQyjwVP0Tys+lU6r2A0DgeKNrv81li4hb+itcdKK3nmWX3Fq9TO7SC4ZfFrY2B+Ys5rulDhAeNh6wc0T9z8RhFO+yccSrFSL4huVfDMWU9OpiSfSJXY+BkVjJbouoMaGdrjI70YPq/OUV/Uq+5PtG73TicaWsqb7Gt+HKm3xfKNsQNP0/lLw+ij/bYz7SQVb5321rxbfTt/nIg0/AXWkDOlmgSUCgYEA4YYvwVPJSSxurWr355Ih9GySpXZq5MkQz4anKizLTtwN0VIQbkP7NL7LlWvIyerZQ5Z0i0tLOIgcdUsetGPeGMQE8JFwpUEPtMZdiiPSIJ2RfboVXGrHNipzoaWqUxePsCs9iZrm9bs0h7/QXLbKjtapeCspD5b8brr0sHLm74sCgYEA13gd3/58Fu8KFz3QjSsM/8pOlckp50aaUP3Pp7t21Ah2rCM6YwQ7DEVyP7t/GfUhsbE6+g4mWFKvc7s/ARYb3i9G1FtzcDQIFynPMrczgDVyVNUwAtAufpQ+a/RO8DhFpO7vpD6RRh+mJ1vNXy+GHTSSHaGXwYYJvGBr9dueb6MCgYEAjcefZCn5hEAjwHBcM8AiCpjrRIyCvRxOrjjYBOKuWgBry2mNHNUuK0W7lU9ypsY3Go+O6zdFrd+cDH1Sa1PRf75T4K1+pNWXOy3uBndolcqZefIvla8nWD0t/rS4tI4+biFxCX5RrrCnYKRNKMxd4ZjAZ+SyZrOkNTThucAywOsCgYEAxm6dfMK9/tTngx3vaYKjNxJWKwWWrKJNzZbhXUR8m6qrt729sKCdzKBMJjuDQyGIhT+F4/GSCLclU7y2ukZlJcp+PWV3O3b/mG1tnvQu3rzZ7RxkWcLlfrcBgaP96qa4JLvTQHxKh7zv5MFbsnRu24ilo9pEivnpD23xHvvBvmcCgYEAt2x0NfxxNp5YJPxLvoBMhA4VF9zwjFzVzyc2H2ktzlbSwqwGU8nHr6M/Ac/AQVnBOt7aXGbeDKqANhfDJfh5PAA5F0uyBB/6VDjUo9fm67xGIaCFXhyxG0TpEuEqmCHwy+2Ca8rRYu5CivxN4XGAprIKVQtLvgpd1vjDVqMBI8Y=";
    private String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvdGDU0d6R0l3c4KI/NJvmfXgFhmHYMYycT6Lb1QSu+fSUcxcBOwXjeqE6XFdueAoZ2lNdA5U//H2HtCA039d0JRCb7b+leCa8PfcB9/7YLgQHP5THtG59paNdF2igktgA79MszlZpm3v5xtT8Vo1mP/18FnNzjb4Io/OCNXB/62k2LtTVxpVwUggm8DLJJHWQv+U1GyQpww4DjsWvaz+nTbFvcGLJ+8nTBELP1JTaouHUqQlo9r16FK5XGqtXr/fvNsRZYvqK1wPQHRKL7RRQFTBaxhfCuHYPQOg1wCiJtMD5ClaX850273aVF6GTKnRouDu5v31pr7tlyCmC7HKgQIDAQAB";

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Override
    public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
        clients.inMemory()
                .withClient("oauthclient1")
                .secret("oauthsecret1")
                .scopes("read", "write")
                .authorizedGrantTypes("client_credentials")
                .accessTokenValiditySeconds(100)
                .refreshTokenValiditySeconds(100);
    }

    @Bean
    public JwtAccessTokenConverter tokenEnhancer() {
        JwtAccessTokenConverter converter = new JwtAccessTokenConverter();
        converter.setSigningKey(privateKey);
//        converter.setVerifierKey(publicKey);
        return converter;
    }

    @Bean
    public JwtTokenStore tokenStore() {
        return new JwtTokenStore(tokenEnhancer());
    }

    @Override
    public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
        endpoints.authenticationManager(authenticationManager).tokenStore(tokenStore())
                .accessTokenConverter(tokenEnhancer());
    }

    @Override
    public void configure(AuthorizationServerSecurityConfigurer security) throws Exception {
        security.tokenKeyAccess("permitAll()").checkTokenAccess("isAuthenticated()");
    }
}
