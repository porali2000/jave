package com.settleking.service.marksservicev1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarksServiceV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
